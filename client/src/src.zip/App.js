import React from 'react';
// import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'; 
import Dashboard from './component/Admin/Dashboard';
import Students from './component/Admin/Student/Students';
import Teachers from './component/Admin/Teacher/Teachers';

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route exact path="/" component={Dashboard} />
          <Route exact path="/teachers" component={Teachers} />
          <Route exact path="/students" component={Students} />
          <Route exact path="/feedbackforms" component={Dashboard} />
        </Switch>

      </Router>
    </div>
  );
}

export default App;
