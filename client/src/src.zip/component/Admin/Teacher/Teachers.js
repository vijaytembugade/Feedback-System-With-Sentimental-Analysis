import React, { useEffect, useState } from 'react'
import { Button, Container, createMuiTheme, FormControl, Grid, InputLabel, makeStyles, MenuItem, Paper, Select, SwipeableDrawer, TextField, ThemeProvider, Typography } from '@material-ui/core';
import SideBar from '../SideBar'
// import HeaderFilters from '../Teacher/Table/TeacherTable';
import 'react-data-grid/dist/react-data-grid.css';
import Divider from '@material-ui/core/Divider';
import PersonAddIcon from '@material-ui/icons/PersonAdd';
import CustomizedHook from './SubjectInputField';
import ReactDataGrid from 'react-data-grid';
import axios from 'axios';
// import { Toolbar } from 'react-data-grid-addons';


const styles = makeStyles(theme => ({
    section: {
        margin: theme.spacing(2),
    },
    sectionPaper: {
        padding: theme.spacing(2),
    },
    toolbar: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: theme.spacing(0, 1),
        // necessary for content to be below app bar
        ...theme.mixins.toolbar,
    },
    content: {
        // flexGrow: 1,
        padding: theme.spacing(3),
        marginLeft: theme.spacing(7) + 1,
        [theme.breakpoints.up('sm')]: {
            marginLeft: theme.spacing(9) + 1,
        },
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 90,
    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    },
    swipeableDrawer: {
        paddingBottom: theme.spacing(5),
    },
    divider:{
        marginTop: theme.spacing(1),
        marginBottom: theme.spacing(2),
    }
}));


const drawerTheme = createMuiTheme({
    overrides: {
        // Style sheet name ⚛️
        MuiDrawer: {
            // Name of the rule
            paper: {
                // Some CSS
                maxWidth: "550px",
                paddingTop: "10px",
                paddingBottom: "20px",
            },
        },
    },
});


const columns = [
    { key: '_id', name: 'ID', frozen: true, width: 150},
    { key: 'designation', name: 'Designation', frozen: true, width: 150,
},
    { key: 'fname', name: 'First Name', frozen: true, width: 150},
    { key: 'lname', name: 'Last Name', frozen: true, width: 150},
    { key: 'mobile', name: 'Phone Number', width: 250, },
    { key: 'email', name: 'Email Address', width: 250,  },
    { key: 'subjects', name: 'Subjects', width: 550,  },
];

// const rows = [
//     { id: 0, title: 'Example' },
//     { id: 1, title: 'Demo' }
// ];



const Teachers = () => {
    const classes = styles();
    const [open, setOpen] = useState(false);
    const toggleDrawer = (val) => (event) => {
        setOpen(val);
    };
    const initialTeacher = {
        designation: "Mr.",
        fname: "",
        lname: "",
        email: "",
        mobile: "",
        subjects: []
    }
    const [newTeacher, setNewTeacher] = useState(initialTeacher);
    const [rows, setRows] = useState([]);

    const handleChange = (e) => {
        setNewTeacher({
            ...newTeacher,
            [e.target.name]: e.target.value
        });
    }

    const handleCancel = () => {
        setNewTeacher(initialTeacher);
        setOpen(false);
    }

    const handleSubmit = () => {
        axios.post("/api/teachers/create", newTeacher)
        .then(res => {
            setRows(res.data);
            setNewTeacher(initialTeacher);
            setOpen(false);
        })
        .catch(err=>{
            console.log("error in fetching contacts",err);
        })
    }

    useEffect(() => {
        axios.get("/api/teachers/all")
            .then(res => {
                setRows(res.data);
            })
            .catch(err=>{
                console.log("error in fetching contacts",err);
            })
    }, []);

    useEffect(() => {
        console.log(newTeacher);
    }, [newTeacher]);

    const defaultColumnProperties = {
        filterable: true,
        width: 120
      };

    return (
        <div className={classes.content}>
            <div className={classes.toolbar} />
            <SideBar />
            {/* <div> */}


                <Paper className={classes.sectionPaper} elevation={2} >
                    <Grid container direction="column" alignItems="flex-start" style={{marginBottom: "10px"}}>
                        <Grid item>
                            <Button
                                variant="contained"
                                color="primary"
                                size="small"
                                className={classes.button}
                                onClick={() => { setOpen(true) }}
                                startIcon={<PersonAddIcon />}
                            >
                                Add
                            </Button>
                        </Grid>
                    </Grid>
                    <ReactDataGrid
                        columns={columns}
                        rows={rows}
                        
                    />
                    {/* {HeaderFilters()} */}
                </Paper>
            {/* </div> */}


            <ThemeProvider theme={drawerTheme}>
                <SwipeableDrawer
                    anchor={"right"}
                    className={classes.swipeableDrawer}
                    open={open}
                    onClose={toggleDrawer(false)}
                    onOpen={toggleDrawer(true)}

                >

                        <Grid container direction="column" style={{height: "100%"}} justify="space-between">
                            <Grid item>
                                <Container>
                                    <Grid item >
                                        <Typography className={classes.formControl} variant="h5" gutterBottom>
                                            Add New Teacher
                                        </Typography>
                                        <Typography className={classes.formControl} style={{ wordWrap: "break-word" }} variant="caption" gutterBottom>
                                            Fill the details for adding new teacher & click <b>SUBMIT</b> button. Click <b>CANCEL</b> button to cancel the operation
                                        </Typography>
                                    </Grid>
                                </Container>
                                <Divider className={classes.divider} />
                                <Container>
                                    <Grid container direction="column">
                                        <Grid container justify="space-between" >
                                            <Grid item>
                                                <TextField
                                                    id="designation"
                                                    name="designation"
                                                    select
                                                    fullWidth
                                                    label="Select"
                                                    className={classes.formControl}
                                                    value={newTeacher.designation}
                                                    onChange={handleChange}
                                                    helperText="Designation"
                                                    variant="outlined"
                                                >
                                                    {[
                                                        {
                                                            value: 'Mr.',
                                                            label: 'Mr.',
                                                        },
                                                        {
                                                            value: 'Mrs.',
                                                            label: 'Mrs.',
                                                        },
                                                        {
                                                            value: 'Miss',
                                                            label: 'Miss',
                                                        },
                                                        {
                                                            value: 'Mast.',
                                                            label: 'Mast.',
                                                        },
                                                    ].map((option) => (
                                                        <MenuItem key={option.value} value={option.value}>
                                                            {option.label}
                                                        </MenuItem>
                                                    ))}
                                                </TextField>
                                            </Grid>
                                        </Grid>
                                        <Grid container justify="space-between">
                                            <Grid item>
                                                <TextField
                                                    id="fname"
                                                    name="fname"
                                                    fullWidth
                                                    className={classes.formControl}
                                                    label="First Name"
                                                    // defaultValue=""
                                                    defaultValue={newTeacher.fname}
                                                    helperText="First Name"
                                                    variant="outlined"
                                                    onChange={handleChange}
                                                />
                                            </Grid>
                                            <Grid item>
                                                <TextField
                                                    id="lname"
                                                    name="lname"
                                                    fullWidth
                                                    className={classes.formControl}
                                                    label="Last Name."
                                                    defaultValue=""
                                                    helperText="Last Name"
                                                    variant="outlined"
                                                    onChange={handleChange}
                                                />
                                            </Grid>
                                        </Grid>
                                        <Grid container justify="space-between">
                                            <Grid item>
                                                <TextField
                                                    id="email"
                                                    name="email"
                                                    fullWidth
                                                    className={classes.formControl}
                                                    label="Email"
                                                    defaultValue=""
                                                    helperText="Email address"
                                                    variant="outlined"
                                                    onChange={handleChange}
                                                />
                                            </Grid>
                                            <Grid item>
                                                <TextField
                                                    id="mobile"
                                                    name="mobile"
                                                    fullWidth
                                                    className={classes.formControl}
                                                    label="Phone no."
                                                    defaultValue=""
                                                    helperText="Phone Number"
                                                    variant="outlined"
                                                    onChange={handleChange}
                                                />
                                            </Grid>
                                        </Grid>
                                        <Grid container justify="space-between">
                                            <Grid item className={classes.formControl}>
                                                <CustomizedHook handleChange={(val) => {
                                                    setNewTeacher({
                                                        ...newTeacher,
                                                        ["subjects"]: val
                                                    })
                                                }}/>
                                            </Grid>

                                        </Grid>
                                    </Grid>
                                </Container>
                            </Grid>
                            <Grid item>
                                <Container>
                                    <Grid container spacing={2} justify="flex-end">
                                        <Grid item>
                                            <Button variant="outlined" color="secondary" onClick={() => handleCancel()}>
                                                Cancel
                                            </Button>
                                        </Grid>
                                        <Grid item>
                                            <Button variant="contained" color="primary" onClick={handleSubmit}>
                                                Submit
                                            </Button>
                                        </Grid>
                                    </Grid>
                                </Container>
                            </Grid>
                        </Grid>
                    
                </SwipeableDrawer>
            </ThemeProvider>
        </div>
    )
}

export default Teachers